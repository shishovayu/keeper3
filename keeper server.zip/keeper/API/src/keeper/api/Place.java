package keeper.api;

public enum Place {
    KITCHEN,
    BAR
}
