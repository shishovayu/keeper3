package ClientServer;

public interface AccessService {
    //int multiplicat(int a, int b);
}
