import ClientServer.AccessService;
import com.caucho.hessian.server.HessianServlet;

public class Server extends HessianServlet implements AccessService{

}
