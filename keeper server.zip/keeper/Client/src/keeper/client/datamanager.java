//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package keeper.client;

import java.sql.SQLException;
import keeper.api.Position;
import keeper.api.User;

public class datamanager {
    private static datamanager instance;

    private datamanager() {
    }

    public static datamanager getInstance() {
        if (instance == null) {
            instance = new datamanager();
        }

        return instance;
    }

    public void createUser(User user) throws SQLException {


        int userID = user.getUserID();
        String login = user.getLogin();
        String password = user.getPassword();
        String position = user.getPosition();

        String sql = "INSERT INTO User (" +
                "            user_id, user_type, login, password)\n" +
                "    VALUES ("+userID+", '"+position+"', '"+ login + "', '"+ password + "');";
        connectionManager.getInstance().insert(sql);
    }

    public void updateUsers(User user) {
    }

    public void deleteUsers(User user) {
    }

    public void createPosition(Position position) throws SQLException {
        int id = position.getPosition_id();
        String name = position.getPosition_name();
        int price = position.getPrice();
    }

    public void updatePosition(Position position) {
    }

    public void deletePosition(Position position) {
    }
}
