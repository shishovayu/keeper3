//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package keeper.client;

import ClientServer.AccessService;
import com.caucho.hessian.client.HessianProxyFactory;

import java.io.IOException;


public class KeeperClientApplication  {
    public KeeperClientApplication() {
    }

    public static void main(String[] args) throws IOException {
        String serverAddress = "http://localhost:8080/";

        HessianProxyFactory factory = new HessianProxyFactory();
        AccessService accessService = (AccessService) factory.create(AccessService.class, serverAddress + "DataService");
        new Authorization("r_keeper");
    }
}
